/*
 * @Author       : Chivier Humber
 * @Date         : 2021-09-15 21:15:24
 * @LastEditors  : Chivier Humber
 * @LastEditTime : 2021-11-23 16:08:51
 * @Description  : file content
 */
#include "common.h"
#include "memory.h"

namespace virtual_machine_nsp {
    void memory_tp::ReadMemoryFromFile(std::string filename, int beginning_address) {
        // Read from the file
        int i = 0;
        int num = 0;
        int length = 0;
        std::string s;
        std::ifstream srcFile(filename);
        while(srcFile){
            int num = 0;
            srcFile >> s;
            length = s.length();
            for(i = 0; i < length; i++){
                num = num * 2 + s[i] - '0';
            }
            if(num > 32767){
                num = num - 65536;
            }
            memory[beginning_address] = num;
            beginning_address = beginning_address + 1;
        }
    }

    int16_t memory_tp::GetContent(int address) const {
        // get the content
        return (memory[address]);
    }

    int16_t& memory_tp::operator[](int address) {
        // std::cout << "LOOK";
        // get the content
        return (memory[address]);
    }
}; // virtual machine namespace
