/*
 * @Author       : Chivier Humber
 * @Date         : 2021-08-30 14:36:39
 * @LastEditors  : liuly
 * @LastEditTime : 2022-11-15 21:12:51
 * @Description  : header file for small assembler
 */

#include <algorithm>
#include <cstring>
#include <fstream>
#include <iostream>
#include <ostream>
#include <sstream>
#include <string>
#include <tuple>
#include <unordered_map>
#include <vector>

const int kLC3LineLength = 16;

extern bool gIsErrorLogMode;
extern bool gIsHexMode;

const std::vector<std::string> kLC3Pseudos({
    ".ORIG",
    ".END",
    ".STRINGZ",
    ".FILL",
    ".BLKW",
});

const std::vector<std::string> kLC3Commands({
    "ADD",    // 00: "0001" + reg(line[1]) + reg(line[2]) + op(line[3])
    "AND",    // 01: "0101" + reg(line[1]) + reg(line[2]) + op(line[3])
    "BR",     // 02: "0000111" + pcoffset(line[1],9)
    "BRN",    // 03: "0000100" + pcoffset(line[1],9)
    "BRZ",    // 04: "0000010" + pcoffset(line[1],9)
    "BRP",    // 05: "0000001" + pcoffset(line[1],9)
    "BRNZ",   // 06: "0000110" + pcoffset(line[1],9)
    "BRNP",   // 07: "0000101" + pcoffset(line[1],9)
    "BRZP",   // 08: "0000011" + pcoffset(line[1],9)
    "BRNZP",  // 09: "0000111" + pcoffset(line[1],9)
    "JMP",    // 10: "1100000" + reg(line[1]) + "000000"
    "JSR",    // 11: "01001" + pcoffset(line[1],11)
    "JSRR",   // 12: "0100000"+reg(line[1])+"000000"
    "LD",     // 13: "0010" + reg(line[1]) + pcoffset(line[2],9)
    "LDI",    // 14: "1010" + reg(line[1]) + pcoffset(line[2],9)
    "LDR",    // 15: "0110" + reg(line[1]) + reg(line[2]) + offset(line[3])
    "LEA",    // 16: "1110" + reg(line[1]) + pcoffset(line[2],9)
    "NOT",    // 17: "1001" + reg(line[1]) + reg(line[2]) + "111111"
    "RET",    // 18: "1100000111000000"
    "RTI",    // 19: "1000000000000000"
    "ST",     // 20: "0011" + reg(line[1]) + pcoffset(line[2],9)
    "STI",    // 21: "1011" + reg(line[1]) + pcoffset(line[2],9)
    "STR",    // 22: "0111" + reg(line[1]) + reg(line[2]) + offset(line[3])
    "TRAP"    // 23: "11110000" + h2b(line[1],8)
});

const std::vector<std::string> kLC3TrapRoutine({
    "GETC",   // x20
    "OUT",    // x21
    "PUTS",   // x22
    "IN",     // x23
    "PUTSP",  // x24
    "HALT"    // x25
});

const std::vector<std::string> kLC3TrapMachineCode({
    "1111000000100000",
    "1111000000100001",
    "1111000000100010",
    "1111000000100011",
    "1111000000100100",
    "1111000000100101"
});

enum CommandType { OPERATION, PSEUDO };

static inline void SetErrorLogMode(bool error) {
    gIsErrorLogMode = error;
}

static inline void SetHexMode(bool hex) {
    gIsHexMode = hex;
}

// A warpper class for std::unorderd_map in order to map label to its address
class LabelMapType {
private:
    std::unordered_map<std::string, unsigned> labels_;

public:
    void AddLabel(const std::string &str, unsigned address);
    unsigned GetAddress(const std::string &str) const;
};

static inline int IsLC3Pseudo(const std::string &str) {
    int index = 0;
    for (const auto &command : kLC3Pseudos) {
        if (str == command) {
            return index;
        }
        ++index;
    }
    return -1;
}

static inline int IsLC3Command(const std::string &str) {
    int index = 0;
    for (const auto &command : kLC3Commands) {
        if (str == command) {
            return index;
        }
        ++index;
    }
    return -1;
}

static inline int IsLC3TrapRoutine(const std::string &str) {
    int index = 0;
    for (const auto &trap : kLC3TrapRoutine) {
        if (str == trap) {
            return index;
        }
        ++index;
    }
    return -1;
}

static inline int CharToDec(const char &ch) {
    if (ch >= '0' && ch <= '9') {
        return ch - '0';
    }
    if (ch >= 'A' && ch <= 'F') {
        return ch - 'A' + 10;
    }
    return -1;
}

static inline char DecToChar(const int &num) {
    if (num <= 9) {
        return num + '0';
    }
    return num - 10 + 'A';
}

// trim string from both left & right
static inline std::string &Trim(std::string &s) {
    // left （去掉左空格）
    auto n = s.length();
    n = s.length();
    int i = 0;
    for(i = 0; i < n; i++){
        if(s[i] != ' ')
            break;
    }
    s = s.substr(i);
    // left （去掉右空格）
    n = s.length();
    for(i = n-1; i >= 0; i--){
        if(s[i] != ' ')
            break;
    }
    s = s.substr(0, i+1);
    return(s);
}

// Format one line from asm file, do the following:
// 1. remove comments
// 2. convert the line into uppercase
// 3. replace all commas with whitespace (for splitting)
// 4. replace all "\t\n\r\f\v" with whitespace
// 5. remove the leading and trailing whitespace chars
// Note: please implement function Trim first
static std::string FormatLine(const std::string &line) {
    // 1. remove comments
    auto n = line.length();
    int i;
    for(i = 0; i < n; i++){
        if(line[i] == ';')
            break;
    }
    auto s = line.substr(0, i);
    // 2. convert the line into uppercase
    for(i = 0; i < n; i++){
        if(s[i] <= 'z' && s[i] >= 'a')
            s[i] = s[i] + 'Z' - 'z';
    }
    // 3. replace all commas with whitespace (for splitting)
    for(i = 0; i < n; i++){
        if(s[i] == ',')
            s[i] = ' ';
    }
    // 4. replace all "\t\n\r\f\v" with whitespace
    for(i = 0; i < n; i++){
        if(s[i] == '\t' || s[i] == '\n' || s[i] == '\r' || s[i] == '\f' || s[i] == '\v')
            s[i] = ' ';
    }
    // 5. remove the leading and trailing whitespace chars
    s = Trim(s);
    return(s);
}

static int RecognizeNumberValue(const std::string &str) {
    // Convert string `str` into a number and return it
    // 判断进制

    int i = 0;
    int multi = 1;
    if(str[0] == 'x' or str[0] == 'X'){
        multi = 16;
        i = 1;
    }
    else if(str[0] == '#'){
        multi = 10;
        i = 1;
    }
    else{
        return(60000);
    }
    // 是否负数
    int sign = 1;
    if(multi == 10){
        if(str[1] == '-'){
            sign = -1;
            i = 2;
        }
    }
    else{
        if(str[1] == '8' || str[1] == '9' || str[1] == 'A' || str[1] == 'B' || str[1] == 'C' || str[1] == 'D' || str[1] == 'E' || str[1] == 'F'){
            sign = -1;
            i = 1;
        }
    }
    // Convert
    auto n = str.length();
    int num = 0;
    if(multi == 10){
        for(; i < n; i++){
            num = num * multi + str[i] - '0';
        }
        return(sign * num);
    }
    else{
        for(; i < n; i++){
            if(str[i] >= '0' && str[i] <= '9'){
                num = num * multi + str[i] - '0';
            }
            else if(str[i] >= 'A' && str[i] <= 'F'){
                num = num * multi + str[i] - 'A' + 10;
            }
            else{
                return(60000);
            }
        }
        if(sign == -1){
            return(num - 65536);
        }
        return(num);
    }
}

static std::string NumberToAssemble(const int &number) {
    // Convert `number` into a 16 bit binary string
    std::string s = "0000000000000000";
    int abs = number;
    int k = 15;
    int i = 0;
    // 取绝对值
    if(number < 0)
        abs = -1 * number - 1;// 减一取反
    // 转换二进制
    while(abs != 0){
        s[k] = abs % 2 + '0';
        abs = abs / 2;
        k--;
    }
    // 负数
    if(number < 0)
        for(i = 0; i < 16; i++){
            if(s[i] == '0'){
                s[i] = '1';
            }
            else{
                s[i] = '0';
            }
    }
    return(s);
}

static std::string NumberToAssemble(const std::string &number) {
    // Convert `number` into a 16 bit binary string
    // You might use `RecognizeNumberValue` in this function
    auto num = RecognizeNumberValue(number);
    std::string s = "0000000000000000";
    int abs = num;
    int k = 15;
    int i = 0;
    // 取绝对值
    if(num < 0)
        abs = -1 * num - 1;// 减一取反
    // 转换二进制
    while(abs != 0){
        s[k] = abs % 2 + '0';
        abs = abs / 2;
        k--;
    }
    // 负数
    if(num < 0)
        for(i = 0; i < 16; i++){
            if(s[i] == '0'){
                s[i] = '1';
            }
            else{
                s[i] = '0';
            }
    }
    return(s);
}

static std::string ConvertBin2Hex(const std::string &bin) {
    // Convert the binary string `bin` into a hex string
    std::string s = "0000";
    int i = 0;
    int j = 0;
    int temp = 0;
    for(i = 0; i < 4; i++){
        temp = 0;
        for(j = 0; j < 4; j++){
            temp = temp * 2 + bin[i * 4 + j] - '0';
        }
        if(temp >= 0 && temp <= 9)
            temp = temp + '0';
        else{
            temp = temp + 'A' - 10;
        }
        s[i] = temp;
    }
    return(s);
}

class assembler {
    using Commands = std::vector<std::tuple<unsigned, std::string, CommandType>>;

private:
    LabelMapType label_map;
    Commands commands;

    static std::string TranslatePseudo(std::stringstream &command_stream);
    std::string TranslateCommand(std::stringstream &command_stream,
                                 unsigned int current_address);
    std::string TranslateOprand(unsigned int current_address, std::string str,
                                int opcode_length = 3);
    std::string LineLabelSplit(const std::string &line, int current_address);
    int firstPass(std::string &input_filename);
    int secondPass(std::string &output_filename);

public:
    int assemble(std::string &input_filename, std::string &output_filename);
};
